# PlayVideo Android Project (APK / AAB Ready)

Package ID: com.playvideo.app
Target SDK: 34 (Android 14)
Min SDK: 26
Version: 1.0.0 (Code 1)

### Build Instructions:
1. Open this unzipped folder or the 'android' folder in Android Studio (Giraffe / Hedgehog / Iguana / Jellyfish).
2. Sync Gradle files.
3. To build Debug APK:
   Run in terminal: ./gradlew assembleDebug
   Output: app/build/outputs/apk/debug/app-debug.apk
4. To build Google Play Store AAB Bundle:
   Run in terminal: ./gradlew bundleRelease
   Output: app/build/outputs/bundle/release/app-release.aab
5. Upload the .aab to Google Play Console.
